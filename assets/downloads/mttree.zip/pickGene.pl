#!/usr/bin/perl -w
use strict;
use LWP::Simple;
use Getopt::Long;

require "./cpData.pl";

# build DB: perl batchDownload.pl -i list.txt -o cpdb
# test 16s: perl pickGene.pl -i list.txt

# orgnized the input
my $nc_number_list;

GetOptions( "input|i=s" => \$nc_number_list );

# read name list
# my $input_name = file2str($nc_number_list);
my $input_name = $nc_number_list;
print mylog("DEBUG", "Reading input name list.");
chomp $input_name;
#print $input_name;
print mylog("DEBUG", "Name List: $input_name");
my %database = readDBToHash($input_name);
print mylog("DEBUG", "Reading data file.");

# prepare data for tree building
my %toMatrix = getGeneNameMatrix(%database) ;

# construct empty matrix
my @fullGeneList = findFullGeneList(%toMatrix);
my %matrix;
$matrix{"NameList"} = "";
for (my $g = 0; $g < $#fullGeneList; $g++) {
    $matrix{ $fullGeneList[$g] } = "$fullGeneList[$g],";
}

# fill in matrix
foreach my $nc (keys %toMatrix) {
    # for each species
    print mylog("DEBUG", "$nc is parsing");

    # add to namelist
    $matrix{"NameList"} .= "$nc,";
    
    # find and match
    my @nc_genes = split( /,/, $toMatrix{$nc} );

    for (my $find = 0; $find < $#fullGeneList; $find++) {
        if ( grep /^$fullGeneList[$find]/, @nc_genes ) {
            $matrix{ $fullGeneList[$find] } .= "1,";
        } else {
            $matrix{ $fullGeneList[$find] } .= "0,";
        }
    }
}

print mylog("DEBUG", "Done for output.");

printMatrix(%matrix);

sub printMatrix {
    my %matrix = @_;

    my $namelist = $matrix{"NameList"};
    print renameNameList($namelist)."\n";

    my %hash = %matrix;
    foreach my $key (sort keys %hash) {
        my $value = $hash{$key};
        if ( $key eq "NameList" ) {
            next;
        } else{
            chop $value;
            print "$value\n";
        }
    }  
}

# get all species into gene list
sub getGeneNameMatrix {
    # original matrix
    my %databast = @_;

    my %toMatrix;
    foreach my $nc (keys %database) {
        # for each species
        print mylog("DEBUG", "$nc is adding to list.");
        # echo >+NC Number
        foreach my $key (keys %{$database{$nc}}) {
            if ( $key eq 'CDS_Protein.txt') {
                my $protein = $database{$nc}->{$key};
                # cut the long name into short
                my $protein_toMatrix =  nameOnly($protein);
                $toMatrix{$nc} = $protein_toMatrix;
            }
        }
    }

    return %toMatrix;
}

# rename NC number list into species name list
sub renameNameList {
    # NC_list
    $nc_number_list = $_[0];

    my @nc_numbers = split( /,/, $nc_number_list );

    my $re = "";
    for (my $var = 0; $var <= $#nc_numbers; $var++) {
        $re .= getSpeciesName($nc_numbers[$var]).",";
    }
    chop $re;
    return $re;
}

# find the full list of gene
sub findFullGeneList {
    #nameOnly FileStr
    my %nameOnly = @_;

    my @fullList;
    foreach my $key (keys %nameOnly) {
        my $value = $nameOnly{$key};
        #print "$key => $value \n";
        my @genes = split(/,/,$value);
        foreach my $gene (@genes) {
            push(@fullList, $gene);
        }
    }
    my %count;
    my @re = grep { ++$count{ $_ } < 2; } @fullList;
    return sort @re;
}

# filter the name into gene name
sub nameOnly{
    #CDSProtein FileStr
    my $protein = $_[0];

    my $reStr = "";
    # print $protein;
    my @lines = split(/\n/, $protein);
    foreach my $line ( @lines ) {
       chomp $line; 
        if($line =~ /^>lcl.*gene=(.*)\]\s+\[protein=(.*)\]\s+\[protein_id=.*/){
            $reStr .= "$1,";
        }
    }
    return $reStr;
}